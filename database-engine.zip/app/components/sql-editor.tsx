"use client"

import { useState, useRef } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Play, Copy, Download, Clock, CheckCircle, XCircle, Database, Info } from "lucide-react"

interface SQLEditorProps {
  apiBase: string
  tables: string[]
  onQueryExecuted: () => void
  isDemoMode?: boolean
}

interface QueryResult {
  success: boolean
  result?: any
  error?: string
  executionTime?: number
}

export default function SQLEditor({ apiBase, tables, onQueryExecuted, isDemoMode = false }: SQLEditorProps) {
  const [sql, setSql] = useState(`-- Welcome to the Database Engine SQL Editor
-- Try these sample queries:

SELECT * FROM users;

-- SELECT name, email FROM users WHERE age > 25;

-- INSERT INTO users (id, name, email, age) VALUES (6, 'New User', 'new@example.com', 30);

-- CREATE TABLE orders (
--   id INT,
--   user_id INT,
--   product VARCHAR(100),
--   quantity INT,
--   total FLOAT
-- );`)

  const [result, setResult] = useState<QueryResult | null>(null)
  const [isExecuting, setIsExecuting] = useState(false)
  const [queryHistory, setQueryHistory] = useState<Array<{ query: string; timestamp: Date; success: boolean }>>([])

  const textareaRef = useRef<HTMLTextAreaElement>(null)

  const executeSQL = async () => {
    if (!sql.trim()) return

    setIsExecuting(true)
    const startTime = Date.now()

    try {
      const response = await fetch(`${apiBase}/sql`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ sql: sql.trim() }),
      })

      const data = await response.json()
      const executionTime = Date.now() - startTime

      setResult({
        ...data,
        executionTime,
      })

      // Add to history
      setQueryHistory((prev) => [
        {
          query: sql.trim(),
          timestamp: new Date(),
          success: data.success,
        },
        ...prev.slice(0, 9),
      ]) // Keep last 10 queries

      if (data.success) {
        onQueryExecuted()
      }
    } catch (error) {
      setResult({
        success: false,
        error: "Failed to connect to database server",
        executionTime: Date.now() - startTime,
      })
    } finally {
      setIsExecuting(false)
    }
  }

  const insertSampleQuery = (query: string) => {
    setSql(query)
    if (textareaRef.current) {
      textareaRef.current.focus()
    }
  }

  const copyResult = () => {
    if (result?.result) {
      navigator.clipboard.writeText(JSON.stringify(result.result, null, 2))
    }
  }

  const downloadResult = () => {
    if (result?.result) {
      const dataStr = JSON.stringify(result.result, null, 2)
      const dataBlob = new Blob([dataStr], { type: "application/json" })
      const url = URL.createObjectURL(dataBlob)
      const link = document.createElement("a")
      link.href = url
      link.download = `query_result_${new Date().toISOString().slice(0, 19)}.json`
      link.click()
      URL.revokeObjectURL(url)
    }
  }

  const sampleQueries = [
    {
      title: "Select All Users",
      query: "SELECT * FROM users;",
    },
    {
      title: "Select All Products",
      query: "SELECT * FROM products;",
    },
    {
      title: "Filter by Age",
      query: "SELECT name, email FROM users WHERE age > 25;",
    },
    {
      title: "Insert New User",
      query: "INSERT INTO users (id, name, email, age) VALUES (6, 'New User', 'new@example.com', 30);",
    },
    {
      title: "Create New Table",
      query: `CREATE TABLE orders (
  id INT,
  user_id INT,
  product VARCHAR(100),
  quantity INT,
  total FLOAT
);`,
    },
    {
      title: "Create Index",
      query: "CREATE INDEX idx_user_email ON users (email);",
    },
  ]

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* SQL Editor */}
      <div className="lg:col-span-2 space-y-4">
        {isDemoMode && (
          <Alert>
            <Info className="h-4 w-4" />
            <AlertDescription>
              Demo mode: Queries are simulated with sample data. Results may not reflect actual SQL execution.
            </AlertDescription>
          </Alert>
        )}

        <Card>
          <CardHeader>
            <CardTitle>SQL Query Editor</CardTitle>
            <CardDescription>
              Write and execute SQL queries against your database
              {isDemoMode && " (Demo Mode)"}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="relative">
              <Textarea
                ref={textareaRef}
                value={sql}
                onChange={(e) => setSql(e.target.value)}
                placeholder="Enter your SQL query here..."
                className="min-h-[300px] font-mono text-sm"
                onKeyDown={(e) => {
                  if (e.ctrlKey && e.key === "Enter") {
                    e.preventDefault()
                    executeSQL()
                  }
                }}
              />
              <div className="absolute bottom-2 right-2 text-xs text-gray-500">Ctrl+Enter to execute</div>
            </div>

            <div className="flex justify-between items-center">
              <div className="flex items-center space-x-2">
                <Button onClick={executeSQL} disabled={isExecuting || !sql.trim()} className="flex items-center">
                  <Play className="h-4 w-4 mr-2" />
                  {isExecuting ? "Executing..." : "Execute Query"}
                </Button>

                {tables.length > 0 && (
                  <Badge variant="outline">
                    {tables.length} table{tables.length !== 1 ? "s" : ""} available
                  </Badge>
                )}

                {isDemoMode && <Badge variant="secondary">Demo Mode</Badge>}
              </div>

              {result && (
                <div className="flex items-center space-x-2">
                  {result.executionTime && (
                    <Badge variant="secondary">
                      <Clock className="h-3 w-3 mr-1" />
                      {result.executionTime}ms
                    </Badge>
                  )}

                  {result.success ? (
                    <Badge variant="default" className="bg-green-100 text-green-800">
                      <CheckCircle className="h-3 w-3 mr-1" />
                      Success
                    </Badge>
                  ) : (
                    <Badge variant="destructive">
                      <XCircle className="h-3 w-3 mr-1" />
                      Error
                    </Badge>
                  )}
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Query Result */}
        {result && (
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Query Result</CardTitle>
                {result.success && result.result && (
                  <div className="flex space-x-2">
                    <Button variant="outline" size="sm" onClick={copyResult}>
                      <Copy className="h-4 w-4 mr-2" />
                      Copy
                    </Button>
                    <Button variant="outline" size="sm" onClick={downloadResult}>
                      <Download className="h-4 w-4 mr-2" />
                      Download
                    </Button>
                  </div>
                )}
              </div>
            </CardHeader>
            <CardContent>
              {result.success ? (
                <div className="space-y-4">
                  {typeof result.result === "string" ? (
                    <Alert>
                      <AlertDescription>{result.result}</AlertDescription>
                    </Alert>
                  ) : Array.isArray(result.result) ? (
                    <div className="space-y-2">
                      <p className="text-sm text-gray-600">
                        {result.result.length} row{result.result.length !== 1 ? "s" : ""} returned
                      </p>
                      <div className="overflow-x-auto">
                        <table className="min-w-full divide-y divide-gray-200">
                          {result.result.length > 0 && (
                            <>
                              <thead className="bg-gray-50">
                                <tr>
                                  {Object.keys(result.result[0]).map((key) => (
                                    <th
                                      key={key}
                                      className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                                    >
                                      {key}
                                    </th>
                                  ))}
                                </tr>
                              </thead>
                              <tbody className="bg-white divide-y divide-gray-200">
                                {result.result.map((row, index) => (
                                  <tr key={index}>
                                    {Object.values(row).map((value, cellIndex) => (
                                      <td key={cellIndex} className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                        {value !== null ? (
                                          String(value)
                                        ) : (
                                          <span className="text-gray-400 italic">null</span>
                                        )}
                                      </td>
                                    ))}
                                  </tr>
                                ))}
                              </tbody>
                            </>
                          )}
                        </table>
                      </div>
                    </div>
                  ) : (
                    <pre className="bg-gray-50 p-4 rounded-md text-sm overflow-x-auto">
                      {JSON.stringify(result.result, null, 2)}
                    </pre>
                  )}
                </div>
              ) : (
                <Alert variant="destructive">
                  <XCircle className="h-4 w-4" />
                  <AlertDescription>{result.error}</AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>
        )}
      </div>

      {/* Sidebar */}
      <div className="space-y-4">
        {/* Sample Queries */}
        <Card>
          <CardHeader>
            <CardTitle>Sample Queries</CardTitle>
            <CardDescription>Click to insert into editor</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            {sampleQueries.map((sample, index) => (
              <Button
                key={index}
                variant="outline"
                size="sm"
                className="w-full justify-start text-left h-auto p-3 bg-transparent"
                onClick={() => insertSampleQuery(sample.query)}
              >
                <div>
                  <div className="font-medium">{sample.title}</div>
                  <div className="text-xs text-gray-500 mt-1 font-mono">
                    {sample.query.split("\n")[0].slice(0, 30)}...
                  </div>
                </div>
              </Button>
            ))}
          </CardContent>
        </Card>

        {/* Available Tables */}
        {tables.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Available Tables</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {tables.map((table) => (
                  <Button
                    key={table}
                    variant="ghost"
                    size="sm"
                    className="w-full justify-start"
                    onClick={() => insertSampleQuery(`SELECT * FROM ${table};`)}
                  >
                    <Database className="h-4 w-4 mr-2" />
                    {table}
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Query History */}
        {queryHistory.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Query History</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 max-h-60 overflow-y-auto">
                {queryHistory.map((item, index) => (
                  <div
                    key={index}
                    className="p-2 border rounded cursor-pointer hover:bg-gray-50"
                    onClick={() => setSql(item.query)}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <Badge variant={item.success ? "default" : "destructive"} className="text-xs">
                        {item.success ? "Success" : "Error"}
                      </Badge>
                      <span className="text-xs text-gray-500">{item.timestamp.toLocaleTimeString()}</span>
                    </div>
                    <div className="text-xs font-mono text-gray-600 truncate">{item.query.split("\n")[0]}</div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
