"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Checkbox } from "@/components/ui/checkbox"
import { Plus, Trash2, Table, Key, ViewIcon as Index } from "lucide-react"

interface TableManagerProps {
  apiBase: string
  tables: string[]
  onTableCreated: () => void
  onTableDeleted: () => void
}

interface Column {
  name: string
  type: string
  size?: number
  primary_key: boolean
  nullable: boolean
  default_value?: string
}

interface TableInfo {
  name: string
  columns: Array<{
    name: string
    type: string
    size?: number
    primary_key: boolean
    nullable: boolean
  }>
  total_records: number
  total_pages: number
  indexes: string[]
}

export default function TableManager({ apiBase, tables, onTableCreated, onTableDeleted }: TableManagerProps) {
  const [selectedTable, setSelectedTable] = useState<string>("")
  const [tableInfo, setTableInfo] = useState<TableInfo | null>(null)
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [isIndexDialogOpen, setIsIndexDialogOpen] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string>("")

  // Create table form state
  const [newTableName, setNewTableName] = useState("")
  const [newColumns, setNewColumns] = useState<Column[]>([
    { name: "id", type: "INT", primary_key: true, nullable: false },
  ])

  // Create index form state
  const [newIndexName, setNewIndexName] = useState("")
  const [indexColumn, setIndexColumn] = useState("")

  useEffect(() => {
    if (selectedTable) {
      loadTableInfo(selectedTable)
    }
  }, [selectedTable])

  const loadTableInfo = async (tableName: string) => {
    try {
      setLoading(true)
      const response = await fetch(`${apiBase}/tables/${tableName}`)
      const data = await response.json()

      if (data.success) {
        setTableInfo(data.table)
      } else {
        setError(data.error || "Failed to load table info")
      }
    } catch (err) {
      setError("Failed to connect to server")
    } finally {
      setLoading(false)
    }
  }

  const createTable = async () => {
    try {
      setLoading(true)
      const response = await fetch(`${apiBase}/tables`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          name: newTableName,
          columns: newColumns,
        }),
      })

      const data = await response.json()

      if (data.success) {
        setIsCreateDialogOpen(false)
        setNewTableName("")
        setNewColumns([{ name: "id", type: "INT", primary_key: true, nullable: false }])
        onTableCreated()
      } else {
        setError(data.error || "Failed to create table")
      }
    } catch (err) {
      setError("Failed to connect to server")
    } finally {
      setLoading(false)
    }
  }

  const deleteTable = async () => {
    if (!selectedTable) return

    try {
      setLoading(true)
      const response = await fetch(`${apiBase}/tables/${selectedTable}`, {
        method: "DELETE",
      })

      const data = await response.json()

      if (data.success) {
        setIsDeleteDialogOpen(false)
        setSelectedTable("")
        setTableInfo(null)
        onTableDeleted()
      } else {
        setError(data.error || "Failed to delete table")
      }
    } catch (err) {
      setError("Failed to connect to server")
    } finally {
      setLoading(false)
    }
  }

  const createIndex = async () => {
    if (!selectedTable || !newIndexName || !indexColumn) return

    try {
      setLoading(true)
      const response = await fetch(`${apiBase}/tables/${selectedTable}/indexes`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          name: newIndexName,
          column: indexColumn,
        }),
      })

      const data = await response.json()

      if (data.success) {
        setIsIndexDialogOpen(false)
        setNewIndexName("")
        setIndexColumn("")
        loadTableInfo(selectedTable)
      } else {
        setError(data.error || "Failed to create index")
      }
    } catch (err) {
      setError("Failed to connect to server")
    } finally {
      setLoading(false)
    }
  }

  const addColumn = () => {
    setNewColumns([...newColumns, { name: "", type: "VARCHAR", primary_key: false, nullable: true }])
  }

  const removeColumn = (index: number) => {
    setNewColumns(newColumns.filter((_, i) => i !== index))
  }

  const updateColumn = (index: number, field: keyof Column, value: any) => {
    const updated = [...newColumns]
    updated[index] = { ...updated[index], [field]: value }
    setNewColumns(updated)
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Table List */}
      <Card className="shadow-card">
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle>Tables</CardTitle>
            <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
              <DialogTrigger asChild>
                <Button size="sm">
                  <Plus className="h-4 w-4 mr-2" />
                  Create Table
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Create New Table</DialogTitle>
                  <DialogDescription>Define the structure of your new table</DialogDescription>
                </DialogHeader>

                <div className="space-y-4">
                  <div>
                    <Label htmlFor="tableName">Table Name</Label>
                    <Input
                      id="tableName"
                      value={newTableName}
                      onChange={(e) => setNewTableName(e.target.value)}
                      placeholder="Enter table name"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <Label>Columns</Label>
                      <Button type="button" variant="outline" size="sm" onClick={addColumn}>
                        <Plus className="h-4 w-4 mr-2" />
                        Add Column
                      </Button>
                    </div>

                    <div className="space-y-2 max-h-60 overflow-y-auto">
                      {newColumns.map((column, index) => (
                        <div key={index} className="flex items-center space-x-2 p-2 border border-border rounded">
                          <Input
                            placeholder="Column name"
                            value={column.name}
                            onChange={(e) => updateColumn(index, "name", e.target.value)}
                            className="flex-1"
                          />

                          <Select value={column.type} onValueChange={(value) => updateColumn(index, "type", value)}>
                            <SelectTrigger className="w-32">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="INT">INT</SelectItem>
                              <SelectItem value="VARCHAR">VARCHAR</SelectItem>
                              <SelectItem value="FLOAT">FLOAT</SelectItem>
                              <SelectItem value="BOOLEAN">BOOLEAN</SelectItem>
                              <SelectItem value="DATE">DATE</SelectItem>
                            </SelectContent>
                          </Select>

                          {column.type === "VARCHAR" && (
                            <Input
                              type="number"
                              placeholder="Size"
                              value={column.size || ""}
                              onChange={(e) =>
                                updateColumn(index, "size", Number.parseInt(e.target.value) || undefined)
                              }
                              className="w-20"
                            />
                          )}

                          <div className="flex items-center space-x-2">
                            <Checkbox
                              checked={column.primary_key}
                              onCheckedChange={(checked) => updateColumn(index, "primary_key", checked)}
                            />
                            <Label className="text-xs text-muted-foreground">PK</Label>
                          </div>

                          <div className="flex items-center space-x-2">
                            <Checkbox
                              checked={column.nullable}
                              onCheckedChange={(checked) => updateColumn(index, "nullable", checked)}
                            />
                            <Label className="text-xs text-muted-foreground">Null</Label>
                          </div>

                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            onClick={() => removeColumn(index)}
                            disabled={newColumns.length === 1}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button
                    onClick={createTable}
                    disabled={loading || !newTableName || newColumns.some((col) => !col.name)}
                  >
                    {loading ? "Creating..." : "Create Table"}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          {tables.length === 0 ? (
            <p className="text-muted-foreground text-center py-4">No tables found</p>
          ) : (
            <div className="space-y-2">
              {tables.map((table) => (
                <Button
                  key={table}
                  variant={selectedTable === table ? "default" : "ghost"}
                  className="w-full justify-start text-foreground hover:bg-muted"
                  onClick={() => setSelectedTable(table)}
                >
                  <Table className="h-4 w-4 mr-2 text-muted-foreground" />
                  {table}
                </Button>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Table Details */}
      <div className="lg:col-span-2">
        {selectedTable && tableInfo ? (
          <div className="space-y-4">
            <Card className="shadow-card">
              <CardHeader>
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle>{tableInfo.name}</CardTitle>
                    <CardDescription>
                      {tableInfo.total_records} records • {tableInfo.total_pages} pages
                    </CardDescription>
                  </div>

                  <div className="flex space-x-2">
                    <Dialog open={isIndexDialogOpen} onOpenChange={setIsIndexDialogOpen}>
                      <DialogTrigger asChild>
                        <Button variant="outline" size="sm">
                          <Index className="h-4 w-4 mr-2" />
                          Create Index
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Create Index</DialogTitle>
                          <DialogDescription>Create an index on {selectedTable} table</DialogDescription>
                        </DialogHeader>

                        <div className="space-y-4">
                          <div>
                            <Label htmlFor="indexName">Index Name</Label>
                            <Input
                              id="indexName"
                              value={newIndexName}
                              onChange={(e) => setNewIndexName(e.target.value)}
                              placeholder="idx_column_name"
                            />
                          </div>

                          <div>
                            <Label htmlFor="indexColumn">Column</Label>
                            <Select value={indexColumn} onValueChange={setIndexColumn}>
                              <SelectTrigger>
                                <SelectValue placeholder="Select column" />
                              </SelectTrigger>
                              <SelectContent>
                                {tableInfo.columns.map((col) => (
                                  <SelectItem key={col.name} value={col.name}>
                                    {col.name} ({col.type})
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>
                        </div>

                        <DialogFooter>
                          <Button variant="outline" onClick={() => setIsIndexDialogOpen(false)}>
                            Cancel
                          </Button>
                          <Button onClick={createIndex} disabled={loading || !newIndexName || !indexColumn}>
                            {loading ? "Creating..." : "Create Index"}
                          </Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>

                    <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
                      <DialogTrigger asChild>
                        <Button variant="destructive" size="sm">
                          <Trash2 className="h-4 w-4 mr-2" />
                          Delete Table
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Delete Table</DialogTitle>
                          <DialogDescription>
                            Are you sure you want to delete the table "{selectedTable}"? This action cannot be undone
                            and will permanently delete all data.
                          </DialogDescription>
                        </DialogHeader>
                        <DialogFooter>
                          <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
                            Cancel
                          </Button>
                          <Button variant="destructive" onClick={deleteTable} disabled={loading}>
                            {loading ? "Deleting..." : "Delete Table"}
                          </Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {/* Columns */}
                  <div>
                    <h4 className="font-medium mb-2 text-foreground">Columns</h4>
                    <div className="overflow-x-auto">
                      <table className="min-w-full divide-y divide-border">
                        <thead className="bg-muted">
                          <tr>
                            <th className="px-4 py-2 text-left text-xs font-medium text-muted-foreground uppercase">
                              Name
                            </th>
                            <th className="px-4 py-2 text-left text-xs font-medium text-muted-foreground uppercase">
                              Type
                            </th>
                            <th className="px-4 py-2 text-left text-xs font-medium text-muted-foreground uppercase">
                              Size
                            </th>
                            <th className="px-4 py-2 text-left text-xs font-medium text-muted-foreground uppercase">
                              Constraints
                            </th>
                          </tr>
                        </thead>
                        <tbody className="bg-card divide-y divide-border">
                          {tableInfo.columns.map((column, index) => (
                            <tr key={index}>
                              <td className="px-4 py-2 text-sm font-medium text-foreground">{column.name}</td>
                              <td className="px-4 py-2 text-sm text-muted-foreground">{column.type}</td>
                              <td className="px-4 py-2 text-sm text-muted-foreground">{column.size || "-"}</td>
                              <td className="px-4 py-2 text-sm">
                                <div className="flex space-x-1">
                                  {column.primary_key && (
                                    <Badge variant="default" className="text-xs">
                                      <Key className="h-3 w-3 mr-1" />
                                      PK
                                    </Badge>
                                  )}
                                  {!column.nullable && (
                                    <Badge variant="secondary" className="text-xs">
                                      NOT NULL
                                    </Badge>
                                  )}
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  {/* Indexes */}
                  {tableInfo.indexes.length > 0 && (
                    <div>
                      <h4 className="font-medium mb-2 text-foreground">Indexes</h4>
                      <div className="flex flex-wrap gap-2">
                        {tableInfo.indexes.map((index) => (
                          <Badge key={index} variant="outline">
                            <Index className="h-3 w-3 mr-1" />
                            {index}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        ) : selectedTable ? (
          <Card className="shadow-card">
            <CardContent className="flex items-center justify-center py-8">
              <div className="text-center">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
                <p className="text-muted-foreground">Loading table information...</p>
              </div>
            </CardContent>
          </Card>
        ) : (
          <Card className="shadow-card">
            <CardContent className="flex items-center justify-center py-8">
              <div className="text-center">
                <Table className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <p className="text-muted-foreground">Select a table to view its details</p>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Error Alert */}
      {error && (
        <div className="lg:col-span-3">
          <Alert variant="destructive">
            <AlertDescription>
              {error}
              <Button variant="outline" size="sm" className="ml-2 bg-transparent" onClick={() => setError("")}>
                Dismiss
              </Button>
            </AlertDescription>
          </Alert>
        </div>
      )}
    </div>
  )
}
