"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { ChevronLeft, ChevronRight, Plus, RefreshCw, Download, Search } from "lucide-react"

interface DataViewerProps {
  apiBase: string
  tables: string[]
  selectedTable: string
  onTableSelect: (table: string) => void
}

interface TableData {
  data: Record<string, any>[]
  total: number
  limit: number
  offset: number
}

interface TableInfo {
  name: string
  columns: Array<{
    name: string
    type: string
    size?: number
    primary_key: boolean
    nullable: boolean
  }>
  total_records: number
  total_pages: number
  indexes: string[]
}

export default function DataViewer({ apiBase, tables, selectedTable, onTableSelect }: DataViewerProps) {
  const [tableData, setTableData] = useState<TableData | null>(null)
  const [tableInfo, setTableInfo] = useState<TableInfo | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string>("")
  const [currentPage, setCurrentPage] = useState(1)
  const [pageSize, setPageSize] = useState(10)
  const [isInsertDialogOpen, setIsInsertDialogOpen] = useState(false)
  const [newRecord, setNewRecord] = useState<Record<string, any>>({})

  useEffect(() => {
    if (selectedTable) {
      loadTableData()
      loadTableInfo()
    }
  }, [selectedTable, currentPage, pageSize])

  const loadTableData = async () => {
    if (!selectedTable) return

    try {
      setLoading(true)
      const offset = (currentPage - 1) * pageSize
      const response = await fetch(`${apiBase}/tables/${selectedTable}/data?limit=${pageSize}&offset=${offset}`)
      const data = await response.json()

      if (data.success) {
        setTableData(data)
      } else {
        setError(data.error || "Failed to load table data")
      }
    } catch (err) {
      setError("Failed to connect to server")
    } finally {
      setLoading(false)
    }
  }

  const loadTableInfo = async () => {
    if (!selectedTable) return

    try {
      const response = await fetch(`${apiBase}/tables/${selectedTable}`)
      const data = await response.json()

      if (data.success) {
        setTableInfo(data.table)
        // Initialize new record with default values
        const defaultRecord: Record<string, any> = {}
        data.table.columns.forEach((col: any) => {
          defaultRecord[col.name] = col.type === "INT" ? 0 : col.type === "FLOAT" ? 0.0 : ""
        })
        setNewRecord(defaultRecord)
      }
    } catch (err) {
      console.error("Failed to load table info:", err)
    }
  }

  const insertRecord = async () => {
    if (!selectedTable) return

    try {
      setLoading(true)
      const response = await fetch(`${apiBase}/tables/${selectedTable}/records`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ record: newRecord }),
      })

      const data = await response.json()

      if (data.success) {
        setIsInsertDialogOpen(false)
        loadTableData()
        loadTableInfo()
        // Reset form
        if (tableInfo) {
          const defaultRecord: Record<string, any> = {}
          tableInfo.columns.forEach((col) => {
            defaultRecord[col.name] = col.type === "INT" ? 0 : col.type === "FLOAT" ? 0.0 : ""
          })
          setNewRecord(defaultRecord)
        }
      } else {
        setError(data.error || "Failed to insert record")
      }
    } catch (err) {
      setError("Failed to connect to server")
    } finally {
      setLoading(false)
    }
  }

  const exportData = () => {
    if (!tableData?.data) return

    const csvContent = [
      // Header
      Object.keys(tableData.data[0]).join(","),
      // Data rows
      ...tableData.data.map((row) =>
        Object.values(row)
          .map((value) => (typeof value === "string" ? `"${value}"` : value))
          .join(","),
      ),
    ].join("\n")

    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.href = url
    link.download = `${selectedTable}_data.csv`
    link.click()
    URL.revokeObjectURL(url)
  }

  const totalPages = tableData ? Math.ceil(tableData.total / pageSize) : 0

  return (
    <div className="space-y-6">
      {/* Table Selection and Controls */}
      <Card className="shadow-card">
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle>Data Viewer</CardTitle>
              <CardDescription>Browse and manage table data</CardDescription>
            </div>

            <div className="flex items-center space-x-2">
              <Select value={selectedTable} onValueChange={onTableSelect}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Select table" />
                </SelectTrigger>
                <SelectContent>
                  {tables.map((table) => (
                    <SelectItem key={table} value={table}>
                      {table}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {selectedTable && (
                <>
                  <Button variant="outline" size="sm" onClick={loadTableData}>
                    <RefreshCw className="h-4 w-4 mr-2" />
                    Refresh
                  </Button>

                  <Dialog open={isInsertDialogOpen} onOpenChange={setIsInsertDialogOpen}>
                    <DialogTrigger asChild>
                      <Button size="sm">
                        <Plus className="h-4 w-4 mr-2" />
                        Insert Record
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Insert New Record</DialogTitle>
                        <DialogDescription>Add a new record to {selectedTable} table</DialogDescription>
                      </DialogHeader>

                      {tableInfo && (
                        <div className="space-y-4 max-h-96 overflow-y-auto">
                          {tableInfo.columns.map((column) => (
                            <div key={column.name}>
                              <Label htmlFor={column.name}>
                                {column.name}
                                {column.primary_key && (
                                  <Badge variant="default" className="ml-2 text-xs">
                                    PK
                                  </Badge>
                                )}
                                {!column.nullable && (
                                  <Badge variant="secondary" className="ml-2 text-xs">
                                    Required
                                  </Badge>
                                )}
                              </Label>
                              <Input
                                id={column.name}
                                type={column.type === "INT" || column.type === "FLOAT" ? "number" : "text"}
                                step={column.type === "FLOAT" ? "0.01" : undefined}
                                value={newRecord[column.name] || ""}
                                onChange={(e) => {
                                  const value =
                                    column.type === "INT"
                                      ? Number.parseInt(e.target.value) || 0
                                      : column.type === "FLOAT"
                                        ? Number.parseFloat(e.target.value) || 0.0
                                        : e.target.value
                                  setNewRecord({ ...newRecord, [column.name]: value })
                                }}
                                placeholder={`Enter ${column.name}`}
                              />
                            </div>
                          ))}
                        </div>
                      )}

                      <DialogFooter>
                        <Button variant="outline" onClick={() => setIsInsertDialogOpen(false)}>
                          Cancel
                        </Button>
                        <Button onClick={insertRecord} disabled={loading}>
                          {loading ? "Inserting..." : "Insert Record"}
                        </Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>

                  {tableData?.data && tableData.data.length > 0 && (
                    <Button variant="outline" size="sm" onClick={exportData}>
                      <Download className="h-4 w-4 mr-2" />
                      Export CSV
                    </Button>
                  )}
                </>
              )}
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Data Table */}
      {selectedTable && (
        <Card className="shadow-card">
          <CardHeader>
            <div className="flex justify-between items-center">
              <div>
                <CardTitle>{selectedTable}</CardTitle>
                {tableData && (
                  <CardDescription>
                    Showing {tableData.data.length} of {tableData.total} records
                  </CardDescription>
                )}
              </div>

              <div className="flex items-center space-x-2">
                <Label htmlFor="pageSize" className="text-muted-foreground">
                  Rows per page:
                </Label>
                <Select
                  value={pageSize.toString()}
                  onValueChange={(value) => {
                    setPageSize(Number.parseInt(value))
                    setCurrentPage(1)
                  }}
                >
                  <SelectTrigger className="w-20">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="10">10</SelectItem>
                    <SelectItem value="25">25</SelectItem>
                    <SelectItem value="50">50</SelectItem>
                    <SelectItem value="100">100</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex items-center justify-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                <span className="ml-2 text-muted-foreground">Loading data...</span>
              </div>
            ) : tableData?.data && tableData.data.length > 0 ? (
              <div className="space-y-4">
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-border">
                    <thead className="bg-muted">
                      <tr>
                        {Object.keys(tableData.data[0]).map((key) => (
                          <th
                            key={key}
                            className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider"
                          >
                            {key}
                            {tableInfo?.columns.find((col) => col.name === key)?.primary_key && (
                              <Badge variant="default" className="ml-2 text-xs">
                                PK
                              </Badge>
                            )}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="bg-card divide-y divide-border">
                      {tableData.data.map((row, index) => (
                        <tr key={index} className="hover:bg-muted">
                          {Object.values(row).map((value, cellIndex) => (
                            <td key={cellIndex} className="px-6 py-4 whitespace-nowrap text-sm text-foreground">
                              {value !== null ? (
                                typeof value === "boolean" ? (
                                  <Badge variant={value ? "default" : "secondary"}>{value.toString()}</Badge>
                                ) : (
                                  String(value)
                                )
                              ) : (
                                <span className="text-muted-foreground italic">null</span>
                              )}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Pagination */}
                {totalPages > 1 && (
                  <div className="flex items-center justify-between">
                    <div className="text-sm text-muted-foreground">
                      Page {currentPage} of {totalPages}
                    </div>

                    <div className="flex items-center space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                        disabled={currentPage === 1}
                      >
                        <ChevronLeft className="h-4 w-4" />
                        Previous
                      </Button>

                      <div className="flex items-center space-x-1">
                        {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                          const pageNum = Math.max(1, Math.min(totalPages - 4, currentPage - 2)) + i
                          return (
                            <Button
                              key={pageNum}
                              variant={currentPage === pageNum ? "default" : "outline"}
                              size="sm"
                              onClick={() => setCurrentPage(pageNum)}
                              className="w-8 h-8 p-0"
                            >
                              {pageNum}
                            </Button>
                          )
                        })}
                      </div>

                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                        disabled={currentPage === totalPages}
                      >
                        Next
                        <ChevronRight className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-center py-8">
                <Search className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <p className="text-muted-foreground">
                  {selectedTable ? "No data found in this table" : "Select a table to view data"}
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Error Alert */}
      {error && (
        <Card className="border-destructive shadow-card">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <p className="text-destructive">{error}</p>
              <Button variant="outline" size="sm" onClick={() => setError("")}>
                Dismiss
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
