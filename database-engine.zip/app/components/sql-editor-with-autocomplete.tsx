"use client"

import { useState, useRef, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Play, Copy, Download, Clock, CheckCircle, XCircle, Info, Lightbulb } from "lucide-react"
import { Database } from "lucide-react" // Import Database icon

// CodeMirror imports
import { EditorView, keymap } from "@codemirror/view"
import { EditorState, Compartment } from "@codemirror/state"
import { sql, SQLDialect } from "@codemirror/lang-sql"
import {
  autocompletion,
  completionKeymap,
  type CompletionContext,
  type CompletionResult,
} from "@codemirror/autocomplete"
import { defaultKeymap, indentWithTab } from "@codemirror/commands"
import { oneDark } from "@codemirror/theme-one-dark"

interface SQLEditorProps {
  apiBase: string
  tables: string[]
  onQueryExecuted: () => void
  isDemoMode?: boolean
}

interface QueryResult {
  success: boolean
  result?: any
  error?: string
  executionTime?: number
}

interface TableSchema {
  [tableName: string]: {
    columns: Array<{
      name: string
      type: string
      primary_key: boolean
      nullable: boolean
    }>
  }
}

export default function SQLEditorWithAutocomplete({
  apiBase,
  tables,
  onQueryExecuted,
  isDemoMode = false,
}: SQLEditorProps) {
  const [result, setResult] = useState<QueryResult | null>(null)
  const [isExecuting, setIsExecuting] = useState(false)
  const [queryHistory, setQueryHistory] = useState<Array<{ query: string; timestamp: Date; success: boolean }>>([])
  const [tableSchemas, setTableSchemas] = useState<TableSchema>({})
  const [darkMode, setDarkMode] = useState(false)

  const editorRef = useRef<HTMLDivElement>(null)
  const editorViewRef = useRef<EditorView | null>(null)

  // SQL Keywords for autocomplete
  const sqlKeywords = [
    "SELECT",
    "FROM",
    "WHERE",
    "INSERT",
    "INTO",
    "VALUES",
    "UPDATE",
    "SET",
    "DELETE",
    "CREATE",
    "TABLE",
    "INDEX",
    "DROP",
    "ALTER",
    "AND",
    "OR",
    "NOT",
    "NULL",
    "IS",
    "LIKE",
    "IN",
    "BETWEEN",
    "ORDER",
    "BY",
    "GROUP",
    "HAVING",
    "LIMIT",
    "OFFSET",
    "JOIN",
    "INNER",
    "LEFT",
    "RIGHT",
    "OUTER",
    "ON",
    "AS",
    "DISTINCT",
    "COUNT",
    "SUM",
    "AVG",
    "MIN",
    "MAX",
    "ASC",
    "DESC",
    "PRIMARY",
    "KEY",
    "FOREIGN",
    "REFERENCES",
    "UNIQUE",
    "CHECK",
    "DEFAULT",
    "AUTO_INCREMENT",
    "VARCHAR",
    "INT",
    "INTEGER",
    "FLOAT",
    "DOUBLE",
    "DECIMAL",
    "BOOLEAN",
    "DATE",
    "TIME",
    "DATETIME",
    "TIMESTAMP",
    "TEXT",
    "BLOB",
  ]

  // Load table schemas for better autocomplete
  useEffect(() => {
    const loadTableSchemas = async () => {
      const schemas: TableSchema = {}
      for (const tableName of tables) {
        try {
          const response = await fetch(`${apiBase}/tables/${tableName}`)
          const data = await response.json()
          if (data.success) {
            schemas[tableName] = {
              columns: data.table.columns,
            }
          }
        } catch (error) {
          console.warn(`Failed to load schema for table ${tableName}:`, error)
        }
      }
      setTableSchemas(schemas)
    }

    if (tables.length > 0) {
      loadTableSchemas()
    }
  }, [tables, apiBase])

  // Custom SQL completion function
  const sqlCompletion = (context: CompletionContext): CompletionResult | null => {
    const word = context.matchBefore(/\w*/)
    if (!word) return null

    const { from, to } = word
    const text = context.state.doc.toString()
    const beforeCursor = text.slice(0, from)

    // Determine context for better suggestions
    const isAfterFrom = /\bFROM\s+$/i.test(beforeCursor)
    const isAfterSelect = /\bSELECT\s+(?:\w+\s*,\s*)*$/i.test(beforeCursor)
    const isAfterWhere = /\bWHERE\s+(?:\w+\s*[=<>!]+\s*\w+\s+(?:AND|OR)\s+)*$/i.test(beforeCursor)
    const isAfterDot = /\w+\.$/i.test(beforeCursor)

    let options: Array<{ label: string; type: string; info?: string; detail?: string }> = []

    // Table name suggestions after FROM
    if (isAfterFrom) {
      options = tables.map((table) => ({
        label: table,
        type: "table",
        info: `Table: ${table}`,
        detail: `${tableSchemas[table]?.columns.length || 0} columns`,
      }))
    }
    // Column suggestions after table.
    else if (isAfterDot) {
      const tableMatch = beforeCursor.match(/(\w+)\.$/i)
      if (tableMatch) {
        const tableName = tableMatch[1]
        const schema = tableSchemas[tableName]
        if (schema) {
          options = schema.columns.map((col) => ({
            label: col.name,
            type: "column",
            info: `Column: ${col.name}`,
            detail: `${col.type}${col.primary_key ? " (PK)" : ""}${!col.nullable ? " NOT NULL" : ""}`,
          }))
        }
      }
    }
    // Column suggestions after SELECT or WHERE
    else if (isAfterSelect || isAfterWhere) {
      // Add columns from all available tables
      Object.entries(tableSchemas).forEach(([tableName, schema]) => {
        schema.columns.forEach((col) => {
          options.push({
            label: col.name,
            type: "column",
            info: `${tableName}.${col.name}`,
            detail: `${col.type}${col.primary_key ? " (PK)" : ""}`,
          })
          // Also add qualified column names
          options.push({
            label: `${tableName}.${col.name}`,
            type: "column",
            info: `Column: ${col.name}`,
            detail: `${col.type}${col.primary_key ? " (PK)" : ""}`,
          })
        })
      })

      // Add SQL keywords
      sqlKeywords.forEach((keyword) => {
        if (keyword.toLowerCase().startsWith(word.text.toLowerCase())) {
          options.push({
            label: keyword,
            type: "keyword",
            info: `SQL Keyword: ${keyword}`,
          })
        }
      })
    }
    // General keyword suggestions
    else {
      // Add SQL keywords
      sqlKeywords.forEach((keyword) => {
        if (keyword.toLowerCase().startsWith(word.text.toLowerCase())) {
          options.push({
            label: keyword,
            type: "keyword",
            info: `SQL Keyword: ${keyword}`,
          })
        }
      })

      // Add table names
      tables.forEach((table) => {
        if (table.toLowerCase().startsWith(word.text.toLowerCase())) {
          options.push({
            label: table,
            type: "table",
            info: `Table: ${table}`,
            detail: `${tableSchemas[table]?.columns.length || 0} columns`,
          })
        }
      })
    }

    if (options.length === 0) return null

    return {
      from,
      to,
      options: options.map((option) => ({
        label: option.label,
        type: option.type,
        info: option.info,
        detail: option.detail,
        apply: option.label,
      })),
    }
  }

  // Initialize CodeMirror
  useEffect(() => {
    if (!editorRef.current) return

    const themeCompartment = new Compartment()

    const extensions = [
      sql({
        dialect: SQLDialect.define({
          keywords: sqlKeywords.join(" ").toLowerCase(),
        }),
        tables: Object.fromEntries(
          Object.entries(tableSchemas).map(([tableName, schema]) => [tableName, schema.columns.map((col) => col.name)]),
        ),
      }),
      autocompletion({
        override: [sqlCompletion],
        activateOnTyping: true,
        maxRenderedOptions: 10,
      }),
      keymap.of([
        ...completionKeymap,
        ...defaultKeymap,
        indentWithTab,
        {
          key: "Ctrl-Enter",
          run: () => {
            executeSQL()
            return true
          },
        },
        {
          key: "F5",
          run: () => {
            executeSQL()
            return true
          },
        },
      ]),
      themeCompartment.of(darkMode ? oneDark : []),
      EditorView.theme({
        "&": {
          fontSize: "14px",
          backgroundColor: "hsl(var(--card))", // Use card background
          color: "hsl(var(--foreground))", // Use foreground color
        },
        ".cm-editor": {
          borderRadius: "6px",
          border: "1px solid hsl(var(--border))", // Use border color
        },
        ".cm-focused": {
          outline: "2px solid hsl(var(--ring))", // Use ring color for focus
          outlineOffset: "2px",
        },
        ".cm-content": {
          caretColor: "hsl(var(--primary))", // Primary color for caret
        },
        ".cm-selectionBackground": {
          backgroundColor: "hsl(var(--primary) / 0.2)", // Subtle selection background
        },
        ".cm-activeLine": {
          backgroundColor: "hsl(var(--muted) / 0.5)", // Muted background for active line
        },
        ".cm-activeLineGutter": {
          backgroundColor: "hsl(var(--muted) / 0.5)",
        },
        ".cm-gutters": {
          backgroundColor: "hsl(var(--card))", // Card background for gutters
          color: "hsl(var(--muted-foreground))", // Muted foreground for line numbers
          borderRight: "1px solid hsl(var(--border))",
        },
        ".cm-tooltip": {
          backgroundColor: "hsl(var(--popover))", // Popover background for tooltips
          color: "hsl(var(--popover-foreground))", // Popover foreground for tooltip text
          border: "1px solid hsl(var(--border))",
          borderRadius: "4px",
          boxShadow: "0 2px 8px rgba(0,0,0,0.1)",
        },
        ".cm-tooltip.cm-tooltip-autocomplete > ul": {
          fontFamily: "Inter, sans-serif", // Apply Inter font to autocomplete
        },
        ".cm-tooltip-autocomplete li": {
          padding: "4px 8px",
        },
        ".cm-tooltip-autocomplete li.cm-active": {
          backgroundColor: "hsl(var(--primary) / 0.1)", // Subtle primary highlight for active item
          color: "hsl(var(--primary-foreground))", // Text color for active item
        },
        ".cm-completionIcon": {
          fontSize: "12px",
          width: "16px",
          textAlign: "center",
        },
        ".cm-completionIcon-keyword": {
          color: "hsl(220 10% 40%)", // Darker gray for keywords
        },
        ".cm-completionIcon-table": {
          color: "hsl(142 70% 35%)", // Slightly desaturated green for tables
        },
        ".cm-completionIcon-column": {
          color: "hsl(0 70% 50%)", // Slightly desaturated red for columns
        },
        ".cm-selectionMatch": {
          backgroundColor: "hsl(var(--primary) / 0.15)", // Subtle match highlight
        },
        ".cm-matchingBracket": {
          backgroundColor: "hsl(var(--primary) / 0.2)",
          outline: "1px solid hsl(var(--primary))",
        },
      }),
    ]

    const initialDoc = `-- Welcome to the Database Engine SQL Editor with Autocomplete
-- Press Tab or Ctrl+Space for suggestions, Ctrl+Enter to execute

SELECT * FROM users;

-- Try typing to see autocomplete suggestions:
-- SELECT name, email FROM users WHERE age > 25;

-- INSERT INTO users (id, name, email, age) VALUES (6, 'New User', 'new@example.com', 30);

-- CREATE TABLE orders (
--   id INT,
--   user_id INT,
--   product VARCHAR(100),
--   quantity INT,
--   total FLOAT
-- );`

    const startState = EditorState.create({
      doc: initialDoc,
      extensions,
    })

    const view = new EditorView({
      state: startState,
      parent: editorRef.current,
    })

    editorViewRef.current = view

    return () => {
      view.destroy()
    }
  }, [tableSchemas, darkMode])

  const executeSQL = async () => {
    if (!editorViewRef.current) return

    const sql = editorViewRef.current.state.doc.toString().trim()
    if (!sql) return

    setIsExecuting(true)
    const startTime = Date.now()

    try {
      const response = await fetch(`${apiBase}/sql`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ sql }),
      })

      const data = await response.json()
      const executionTime = Date.now() - startTime

      setResult({
        ...data,
        executionTime,
      })

      // Add to history
      setQueryHistory((prev) => [
        {
          query: sql,
          timestamp: new Date(),
          success: data.success,
        },
        ...prev.slice(0, 9),
      ])

      if (data.success) {
        onQueryExecuted()
      }
    } catch (error) {
      setResult({
        success: false,
        error: "Failed to connect to database server",
        executionTime: Date.now() - startTime,
      })
    } finally {
      setIsExecuting(false)
    }
  }

  const insertSampleQuery = (query: string) => {
    if (editorViewRef.current) {
      const transaction = editorViewRef.current.state.update({
        changes: {
          from: 0,
          to: editorViewRef.current.state.doc.length,
          insert: query,
        },
      })
      editorViewRef.current.dispatch(transaction)
      editorViewRef.current.focus()
    }
  }

  const copyResult = () => {
    if (result?.result) {
      navigator.clipboard.writeText(JSON.stringify(result.result, null, 2))
    }
  }

  const downloadResult = () => {
    if (result?.result) {
      const dataStr = JSON.stringify(result.result, null, 2)
      const dataBlob = new Blob([dataStr], { type: "application/json" })
      const url = URL.createObjectURL(dataBlob)
      const link = document.createElement("a")
      link.href = url
      link.download = `query_result_${new Date().toISOString().slice(0, 19)}.json`
      link.click()
      URL.revokeObjectURL(url)
    }
  }

  const sampleQueries = [
    {
      title: "Select All Users",
      query: "SELECT * FROM users;",
    },
    {
      title: "Select All Products",
      query: "SELECT * FROM products;",
    },
    {
      title: "Filter by Age",
      query: "SELECT name, email FROM users WHERE age > 25;",
    },
    {
      title: "Join Tables",
      query: `SELECT u.name, p.name as product_name, o.quantity
FROM users u
JOIN orders o ON u.id = o.user_id
JOIN products p ON o.product_id = p.id;`,
    },
    {
      title: "Insert New User",
      query: "INSERT INTO users (id, name, email, age) VALUES (6, 'New User', 'new@example.com', 30);",
    },
    {
      title: "Create New Table",
      query: `CREATE TABLE orders (
id INT,
user_id INT,
product VARCHAR(100),
quantity INT,
total FLOAT
);`,
    },
    {
      title: "Create Index",
      query: "CREATE INDEX idx_user_email ON users (email);",
    },
  ]

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* SQL Editor */}
      <div className="lg:col-span-2 space-y-4">
        {isDemoMode && (
          <Alert>
            <Info className="h-4 w-4" />
            <AlertDescription>
              Demo mode: Queries are simulated with sample data. Autocomplete features are fully functional.
            </AlertDescription>
          </Alert>
        )}

        <Card className="shadow-card">
          <CardHeader>
            <div className="flex justify-between items-center">
              <div>
                <CardTitle>SQL Query Editor with Autocomplete</CardTitle>
                <CardDescription>
                  Write SQL queries with intelligent autocomplete and syntax highlighting
                  {isDemoMode && " (Demo Mode)"}
                </CardDescription>
              </div>
              <Button variant="outline" size="sm" onClick={() => setDarkMode(!darkMode)}>
                {darkMode ? "Light" : "Dark"} Theme
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="relative">
              <div ref={editorRef} className="min-h-[300px] border rounded-md" />
              
            </div>

            <div className="flex justify-between items-center">
              <div className="flex items-center space-x-2">
                <Button onClick={executeSQL} disabled={isExecuting} className="flex items-center">
                  <Play className="h-4 w-4 mr-2" />
                  {isExecuting ? "Executing..." : "Execute Query"}
                </Button>

                {tables.length > 0 && (
                  <Badge variant="outline">
                    {tables.length} table{tables.length !== 1 ? "s" : ""} available
                  </Badge>
                )}

                {isDemoMode && <Badge variant="secondary">Demo Mode</Badge>}

                <Badge variant="outline" className="bg-blue-50 text-blue-700">
                  <Lightbulb className="h-3 w-3 mr-1" />
                  Smart Autocomplete
                </Badge>
              </div>

              {result && (
                <div className="flex items-center space-x-2">
                  {result.executionTime && (
                    <Badge variant="secondary">
                      <Clock className="h-3 w-3 mr-1" />
                      {result.executionTime}ms
                    </Badge>
                  )}

                  {result.success ? (
                    <Badge variant="default" className="bg-green-100 text-green-800">
                      <CheckCircle className="h-3 w-3 mr-1" />
                      Success
                    </Badge>
                  ) : (
                    <Badge variant="destructive">
                      <XCircle className="h-3 w-3 mr-1" />
                      Error
                    </Badge>
                  )}
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Query Result */}
        {result && (
          <Card className="shadow-card">
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Query Result</CardTitle>
                {result.success && result.result && (
                  <div className="flex space-x-2">
                    <Button variant="outline" size="sm" onClick={copyResult}>
                      <Copy className="h-4 w-4 mr-2" />
                      Copy
                    </Button>
                    <Button variant="outline" size="sm" onClick={downloadResult}>
                      <Download className="h-4 w-4 mr-2" />
                      Download
                    </Button>
                  </div>
                )}
              </div>
            </CardHeader>
            <CardContent>
              {result.success ? (
                <div className="space-y-4">
                  {typeof result.result === "string" ? (
                    <Alert>
                      <AlertDescription>{result.result}</AlertDescription>
                    </Alert>
                  ) : Array.isArray(result.result) ? (
                    <div className="space-y-2">
                      <p className="text-sm text-muted-foreground">
                        {result.result.length} row{result.result.length !== 1 ? "s" : ""} returned
                      </p>
                      <div className="overflow-x-auto">
                        <table className="min-w-full divide-y divide-border">
                          {result.result.length > 0 && (
                            <>
                              <thead className="bg-muted">
                                <tr>
                                  {Object.keys(result.result[0]).map((key) => (
                                    <th
                                      key={key}
                                      className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider"
                                    >
                                      {key}
                                    </th>
                                  ))}
                                </tr>
                              </thead>
                              <tbody className="bg-card divide-y divide-border">
                                {result.result.map((row, index) => (
                                  <tr key={index}>
                                    {Object.values(row).map((value, cellIndex) => (
                                      <td
                                        key={cellIndex}
                                        className="px-6 py-4 whitespace-nowrap text-sm text-foreground"
                                      >
                                        {value !== null ? (
                                          String(value)
                                        ) : (
                                          <span className="text-muted-foreground italic">null</span>
                                        )}
                                      </td>
                                    ))}
                                  </tr>
                                ))}
                              </tbody>
                            </>
                          )}
                        </table>
                      </div>
                    </div>
                  ) : (
                    <pre className="bg-muted p-4 rounded-md text-sm overflow-x-auto text-foreground">
                      {JSON.stringify(result.result, null, 2)}
                    </pre>
                  )}
                </div>
              ) : (
                <Alert variant="destructive">
                  <XCircle className="h-4 w-4" />
                  <AlertDescription>{result.error}</AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>
        )}
      </div>

      {/* Sidebar */}
      <div className="space-y-4">
        {/* Autocomplete Help */}
        <Card className="shadow-card">
          
          
        </Card>

        {/* Sample Queries */}
        <Card className="shadow-card">
          <CardHeader>
            <CardTitle>Sample Queries</CardTitle>
            <CardDescription>Click to insert into editor</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            {sampleQueries.map((sample, index) => (
              <Button
                key={index}
                variant="outline"
                size="sm"
                className="w-full justify-start text-left h-auto p-3 bg-transparent hover:bg-muted"
                onClick={() => insertSampleQuery(sample.query)}
              >
                <div>
                  <div className="font-medium text-foreground">{sample.title}</div>
                  <div className="text-xs text-muted-foreground mt-1 font-mono">
                    {sample.query.split("\n")[0].slice(0, 30)}...
                  </div>
                </div>
              </Button>
            ))}
          </CardContent>
        </Card>

        {/* Available Tables */}
        {tables.length > 0 && (
          <Card className="shadow-card">
            
            
          </Card>
        )}

        {/* Query History */}
        {queryHistory.length > 0 && (
          <Card className="shadow-card">
            <CardHeader>
              <CardTitle>Query History</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 max-h-60 overflow-y-auto">
                {queryHistory.map((item, index) => (
                  <div
                    key={index}
                    className="p-2 border border-border rounded cursor-pointer hover:bg-muted"
                    onClick={() => insertSampleQuery(item.query)}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <Badge variant={item.success ? "default" : "destructive"} className="text-xs">
                        {item.success ? "Success" : "Error"}
                      </Badge>
                      <span className="text-xs text-muted-foreground">{item.timestamp.toLocaleTimeString()}</span>
                    </div>
                    <div className="text-xs font-mono text-foreground truncate">{item.query.split("\n")[0]}</div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
