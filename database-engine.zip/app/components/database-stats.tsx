"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { RefreshCw, Database, Table, BarChart3, HardDrive } from "lucide-react"

interface DatabaseStatsProps {
  apiBase: string
  stats: {
    total_tables: number
    total_records: number
    tables: Record<
      string,
      {
        records: number
        pages: number
        columns: number
        indexes: number
      }
    >
  } | null
  onRefresh: () => void
}

export default function DatabaseStats({ apiBase, stats, onRefresh }: DatabaseStatsProps) {
  if (!stats) {
    return (
      <Card className="shadow-card">
        <CardContent className="flex items-center justify-center py-8">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-muted-foreground">Loading database statistics...</p>
          </div>
        </CardContent>
      </Card>
    )
  }

  const maxRecords = Math.max(...Object.values(stats.tables).map((t) => t.records))
  const maxPages = Math.max(...Object.values(stats.tables).map((t) => t.pages))

  return (
    <div className="space-y-6">
      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="shadow-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Tables</CardTitle>
            <Table className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">{stats.total_tables}</div>
          </CardContent>
        </Card>

        <Card className="shadow-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Records</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">{stats.total_records.toLocaleString()}</div>
          </CardContent>
        </Card>

        <Card className="shadow-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Pages</CardTitle>
            <HardDrive className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">
              {Object.values(stats.tables).reduce((sum, table) => sum + table.pages, 0)}
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Indexes</CardTitle>
            <Database className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-foreground">
              {Object.values(stats.tables).reduce((sum, table) => sum + table.indexes, 0)}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Table Statistics */}
      <Card className="shadow-card">
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle>Table Statistics</CardTitle>
              <CardDescription>Detailed breakdown by table</CardDescription>
            </div>
            <Button variant="outline" size="sm" onClick={onRefresh}>
              <RefreshCw className="h-4 w-4 mr-2" />
              Refresh
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {Object.entries(stats.tables).map(([tableName, tableStats]) => (
              <div key={tableName} className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-medium text-foreground">{tableName}</h4>
                  <div className="flex items-center space-x-2">
                    <Badge variant="secondary">{tableStats.records} records</Badge>
                    <Badge variant="outline">{tableStats.columns} columns</Badge>
                    {tableStats.indexes > 0 && <Badge variant="default">{tableStats.indexes} indexes</Badge>}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm text-muted-foreground">
                      <span>Records</span>
                      <span>{tableStats.records.toLocaleString()}</span>
                    </div>
                    <Progress value={maxRecords > 0 ? (tableStats.records / maxRecords) * 100 : 0} className="h-2" />
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between text-sm text-muted-foreground">
                      <span>Pages</span>
                      <span>{tableStats.pages}</span>
                    </div>
                    <Progress value={maxPages > 0 ? (tableStats.pages / maxPages) * 100 : 0} className="h-2" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Performance Insights */}
      <Card className="shadow-card">
        <CardHeader>
          <CardTitle>Performance Insights</CardTitle>
          <CardDescription>Recommendations for optimization</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {Object.entries(stats.tables).flatMap(([tableName, tableStats]) => {
              const insights = []

              if (tableStats.records > 1000 && tableStats.indexes === 0) {
                insights.push({
                  type: "warning",
                  message: `Consider adding indexes to ${tableName} for better query performance`,
                })
              }

              if (tableStats.pages > 10) {
                insights.push({
                  type: "info",
                  message: `${tableName} uses ${tableStats.pages} pages - consider data archiving if appropriate`,
                })
              }

              if (tableStats.records === 0) {
                insights.push({
                  type: "info",
                  message: `${tableName} is empty - consider adding sample data`,
                })
              }

              return insights.map((insight, index) => (
                <div
                  key={`${tableName}-${index}`}
                  className={`p-3 rounded-md border ${
                    insight.type === "warning"
                      ? "bg-yellow-50 border-yellow-200 text-yellow-800"
                      : "bg-blue-50 border-blue-200 text-blue-800"
                  }`}
                >
                  {insight.message}
                </div>
              ))
            })}

            {Object.values(stats.tables).every(
              (table) => table.records > 0 && (table.records <= 1000 || table.indexes > 0),
            ) && (
              <div className="p-3 rounded-md border bg-green-50 border-green-200 text-green-800">
                Your database appears to be well-optimized! All tables have appropriate indexes or manageable record
                counts.
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
