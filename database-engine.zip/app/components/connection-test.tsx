"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { CheckCircle, XCircle, RefreshCw, Server, Terminal } from "lucide-react"

interface ConnectionTestProps {
  apiBase: string
}

export default function ConnectionTest({ apiBase }: ConnectionTestProps) {
  const [status, setStatus] = useState<"testing" | "connected" | "disconnected">("testing")
  const [error, setError] = useState<string>("")
  const [details, setDetails] = useState<string>("")
  const [serverInfo, setServerInfo] = useState<any>(null)

  const testConnection = async () => {
    setStatus("testing")
    setError("")
    setDetails("")

    try {
      const response = await fetch(`${apiBase}/health`)
      const data = await response.json()

      if (response.ok && data.status === "healthy") {
        setStatus("connected")
        setServerInfo(data)
      } else {
        setStatus("disconnected")
        setError(data.error || data.message || "Server is not healthy")
        setDetails(data.details || "")
      }
    } catch (err: any) {
      setStatus("disconnected")
      setError(err.message || "Failed to connect to server")
    }
  }

  useEffect(() => {
    testConnection()
  }, [])

  return (
    <div className="space-y-6">
      <Card className="shadow-card">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Server className="h-5 w-5 mr-2 text-foreground" />
            Database Server Connection
          </CardTitle>
          <CardDescription>Test connection to the Python API server</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              {status === "testing" && (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-primary" />
                  <span className="text-muted-foreground">Testing connection...</span>
                </>
              )}

              {status === "connected" && (
                <>
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <span className="text-foreground">Connected</span>
                  <Badge variant="default" className="bg-green-100 text-green-800">
                    Healthy
                  </Badge>
                </>
              )}

              {status === "disconnected" && (
                <>
                  <XCircle className="h-4 w-4 text-destructive" />
                  <span className="text-foreground">Disconnected</span>
                  <Badge variant="destructive">Error</Badge>
                </>
              )}
            </div>

            <Button variant="outline" size="sm" onClick={testConnection} disabled={status === "testing"}>
              <RefreshCw className="h-4 w-4 mr-2" />
              Test Again
            </Button>
          </div>

          {status === "connected" && serverInfo && (
            <div className="p-3 bg-green-50 border border-green-200 rounded-md text-green-800">
              <p className="text-sm">✓ Server is running with {serverInfo.tables_count || 0} tables</p>
            </div>
          )}

          {status === "disconnected" && (
            <Alert variant="destructive">
              <XCircle className="h-4 w-4" />
              <AlertDescription>
                <div className="space-y-3">
                  <p>
                    <strong>Connection failed:</strong> {error}
                  </p>
                  {details && (
                    <p className="text-sm">
                      <strong>Details:</strong> {details}
                    </p>
                  )}
                </div>
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {status === "disconnected" && (
        <Card className="shadow-card">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Terminal className="h-5 w-5 mr-2 text-foreground" />
              Setup Instructions
            </CardTitle>
            <CardDescription>Follow these steps to start the database server</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-start space-x-3">
                <div className="flex-shrink-0 w-6 h-6 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-sm font-medium">
                  1
                </div>
                <div>
                  <p className="font-medium text-foreground">Install Python dependencies</p>
                  <div className="mt-1 p-2 bg-muted rounded font-mono text-sm text-foreground">
                    pip install flask flask-cors
                  </div>
                </div>
              </div>

              <div className="flex items-start space-x-3">
                <div className="flex-shrink-0 w-6 h-6 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-sm font-medium">
                  2
                </div>
                <div>
                  <p className="font-medium text-foreground">Start the database server</p>
                  <div className="mt-1 p-2 bg-muted rounded font-mono text-sm text-foreground">
                    python scripts/start_server.py
                  </div>
                </div>
              </div>

              <div className="flex items-start space-x-3">
                <div className="flex-shrink-0 w-6 h-6 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-sm font-medium">
                  3
                </div>
                <div>
                  <p className="font-medium text-foreground">Verify server is running</p>
                  <p className="text-sm text-muted-foreground mt-1">
                    The server should start on <code className="bg-muted px-1 rounded">http://localhost:5000</code>
                  </p>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-border">
              <h4 className="font-medium mb-2 text-foreground">Troubleshooting</h4>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Make sure Python 3.7+ is installed</li>
                <li>• Check that port 5000 is not in use by another application</li>
                <li>• Ensure you're in the correct directory when running the script</li>
                <li>• Check the terminal for any error messages from the Python server</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
