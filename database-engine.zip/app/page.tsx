"use client"

import { useState, useEffect } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Database, TableIcon, Play, BarChart3, RefreshCw, Info } from "lucide-react"
import SQLEditorWithAutocomplete from "./components/sql-editor-with-autocomplete"
import TableManager from "./components/table-manager"
import DataViewer from "./components/data-viewer"
import DatabaseStatsComponent from "./components/database-stats"
import ConnectionTest from "./components/connection-test"

interface DatabaseStats {
  total_tables: number
  total_records: number
  tables: Record<
    string,
    {
      records: number
      pages: number
      columns: number
      indexes: number
    }
  >
}

export default function DatabaseEngine() {
  const [tables, setTables] = useState<string[]>([])
  const [selectedTable, setSelectedTable] = useState<string>("")
  const [stats, setStats] = useState<DatabaseStats | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string>("")
  const [connectionStatus, setConnectionStatus] = useState<"connecting" | "connected" | "disconnected" | "demo">(
    "connecting",
  )
  const [showConnectionTest, setShowConnectionTest] = useState(false)

  const API_BASE = "/api"
  const DEMO_API_BASE = "/api/demo"

  const checkConnection = async () => {
    try {
      console.log("Checking connection to Python server...")
      const response = await fetch(`${API_BASE}/health`)
      const data = await response.json()

      if (response.ok && data.status === "healthy") {
        console.log("✓ Connected to Python server")
        setConnectionStatus("connected")
        setError("")
        return { success: true, apiBase: API_BASE }
      } else {
        console.log("✗ Python server responded but not healthy:", data)
        throw new Error(data.error || "Server not healthy")
      }
    } catch (err: any) {
      console.log("✗ Cannot connect to Python server, trying demo mode...")
      setConnectionStatus("demo")
      setError("")
      return { success: true, apiBase: DEMO_API_BASE }
    }
  }

  const loadTables = async (apiBase: string) => {
    try {
      const response = await fetch(`${apiBase}/tables`)
      const data = await response.json()

      if (response.ok && data.success) {
        setTables(data.tables)
        if (data.tables.length > 0 && !selectedTable) {
          setSelectedTable(data.tables[0])
        }
        return true
      } else {
        setError(data.error || "Failed to load tables")
        return false
      }
    } catch (err: any) {
      setError(err.message || "Failed to load tables")
      return false
    }
  }

  const loadStats = async (apiBase: string) => {
    try {
      const response = await fetch(`${apiBase}/database/stats`)
      const data = await response.json()

      if (response.ok && data.success) {
        setStats(data.stats)
        return true
      } else {
        console.warn("Failed to load stats:", data.error)
        return false
      }
    } catch (err) {
      console.warn("Failed to load stats:", err)
      return false
    }
  }

  const initializeApp = async () => {
    setIsLoading(true)
    setError("")

    const connectionResult = await checkConnection()
    if (connectionResult.success) {
      await loadTables(connectionResult.apiBase)
      await loadStats(connectionResult.apiBase)
    }

    setIsLoading(false)
  }

  useEffect(() => {
    initializeApp()
  }, [])

  const handleTableCreated = () => {
    const apiBase = connectionStatus === "demo" ? DEMO_API_BASE : API_BASE
    loadTables(apiBase)
    loadStats(apiBase)
  }

  const handleTableDeleted = () => {
    const apiBase = connectionStatus === "demo" ? DEMO_API_BASE : API_BASE
    loadTables(apiBase)
    loadStats(apiBase)
    setSelectedTable("")
  }

  const handleRetry = () => {
    setShowConnectionTest(false)
    initializeApp()
  }

  const getApiBase = () => {
    return connectionStatus === "demo" ? DEMO_API_BASE : API_BASE
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <Database className="h-12 w-12 mx-auto mb-4 text-primary animate-pulse" />
          <p className="text-foreground">Connecting to database engine...</p>
          <p className="text-sm text-muted-foreground mt-2">Checking Python server availability...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-card border-b border-border shadow-card">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center">
              <Database className="h-8 w-8 text-primary mr-3" />
              <div>
                <h1 className="text-2xl font-bold text-foreground">Database Engine</h1>
                <p className="text-sm text-muted-foreground">Custom SQL Database with Smart Autocomplete</p>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <div
                  className={`w-2 h-2 rounded-full ${
                    connectionStatus === "connected"
                      ? "bg-green-500"
                      : connectionStatus === "demo"
                        ? "bg-blue-500"
                        : connectionStatus === "connecting"
                          ? "bg-yellow-500 animate-pulse"
                          : "bg-red-500"
                  }`}
                />
                <span className="text-sm text-muted-foreground">
                  {connectionStatus === "connected"
                    ? "Connected"
                    : connectionStatus === "demo"
                      ? "Demo Mode"
                      : connectionStatus === "connecting"
                        ? "Connecting..."
                        : "Disconnected"}
                </span>
              </div>

              {connectionStatus === "demo" && (
                <Button variant="outline" size="sm" onClick={() => setShowConnectionTest(true)}>
                  Setup Server
                </Button>
              )}

              {connectionStatus === "disconnected" && (
                <Button variant="outline" size="sm" onClick={handleRetry}>
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Retry
                </Button>
              )}

              {stats && (
                <div className="flex items-center space-x-4">
                  <Badge variant="secondary">
                    <TableIcon className="h-3 w-3 mr-1" />
                    {stats.total_tables} Tables
                  </Badge>
                  <Badge variant="secondary">
                    <BarChart3 className="h-3 w-3 mr-1" />
                    {stats.total_records} Records
                  </Badge>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>
      {connectionStatus === "demo" && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-4">
          <Alert>
            <Info className="h-4 w-4" />
            <AlertDescription>
              <div className="flex items-center justify-between">
                <span>
                  You're in <strong>demo mode</strong> with full autocomplete features. To use the Python backend, click
                  "Setup Server".
                </span>
                <Button variant="outline" size="sm" onClick={() => setShowConnectionTest(true)}>
                  Setup Server
                </Button>
              </div>
            </AlertDescription>
          </Alert>
        </div>
      )}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {showConnectionTest ? (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold text-foreground">Server Setup</h2>
              <Button variant="outline" onClick={() => setShowConnectionTest(false)}>
                Back to Demo
              </Button>
            </div>
            <ConnectionTest apiBase={API_BASE} />
          </div>
        ) : (
          <Tabs defaultValue="sql" className="space-y-6">
            <TabsList className="grid w-full grid-cols-4 bg-muted">
              <TabsTrigger value="sql" className="flex items-center">
                <Play className="h-4 w-4 mr-2" />
                SQL Editor
              </TabsTrigger>
              <TabsTrigger value="tables" className="flex items-center">
                <TableIcon className="h-4 w-4 mr-2" />
                Table Manager
              </TabsTrigger>
              <TabsTrigger value="data" className="flex items-center">
                <Database className="h-4 w-4 mr-2" />
                Data Viewer
              </TabsTrigger>
              <TabsTrigger value="stats" className="flex items-center">
                <BarChart3 className="h-4 w-4 mr-2" />
                Statistics
              </TabsTrigger>
            </TabsList>

            <TabsContent value="sql" className="space-y-6">
              <SQLEditorWithAutocomplete
                apiBase={getApiBase()}
                tables={tables}
                onQueryExecuted={() => {
                  loadTables(getApiBase())
                  loadStats(getApiBase())
                }}
                isDemoMode={connectionStatus === "demo"}
              />
            </TabsContent>

            <TabsContent value="tables" className="space-y-6">
              <TableManager
                apiBase={getApiBase()}
                tables={tables}
                onTableCreated={handleTableCreated}
                onTableDeleted={handleTableDeleted}
              />
            </TabsContent>

            <TabsContent value="data" className="space-y-6">
              <DataViewer
                apiBase={getApiBase()}
                tables={tables}
                selectedTable={selectedTable}
                onTableSelect={setSelectedTable}
              />
            </TabsContent>

            <TabsContent value="stats" className="space-y-6">
              <DatabaseStatsComponent apiBase={getApiBase()} stats={stats} onRefresh={() => loadStats(getApiBase())} />
            </TabsContent>
          </Tabs>
        )}
      </main>
    </div>
  )
}
