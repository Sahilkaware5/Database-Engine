import { type NextRequest, NextResponse } from "next/server"

const PYTHON_API_BASE = "http://localhost:5000/api"

// Create a timeout promise
function createTimeout(ms: number): Promise<never> {
  return new Promise((_, reject) => {
    setTimeout(() => reject(new Error("Request timeout")), ms)
  })
}

async function makeRequest(url: string, options: RequestInit = {}) {
  try {
    console.log(`[API Proxy] Attempting request to: ${url}`)

    // Race between fetch and timeout
    const fetchPromise = fetch(url, {
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...options.headers,
      },
    })

    const timeoutPromise = createTimeout(5000) // 5 second timeout

    const response = await Promise.race([fetchPromise, timeoutPromise])

    console.log(`[API Proxy] Response status: ${response.status}`)

    if (!response.ok) {
      let errorText = ""
      try {
        errorText = await response.text()
      } catch {
        errorText = response.statusText
      }

      console.error(`[API Proxy] Python API error: ${response.status} - ${errorText}`)

      return NextResponse.json(
        {
          success: false,
          error: `Python API error (${response.status}): ${errorText || response.statusText}`,
        },
        { status: response.status },
      )
    }

    const data = await response.json()
    console.log(`[API Proxy] Success: ${JSON.stringify(data).substring(0, 100)}...`)
    return NextResponse.json(data)
  } catch (error: any) {
    console.error("[API Proxy] Error details:", {
      message: error.message,
      name: error.name,
      code: error.code,
      cause: error.cause,
    })

    // Handle different types of errors
    if (error.message === "Request timeout") {
      return NextResponse.json(
        {
          success: false,
          error: "Request timeout - Python API server may be slow or unresponsive",
          details: "The server took too long to respond. Please check if the Python server is running.",
        },
        { status: 408 },
      )
    }

    if (error.code === "ECONNREFUSED" || error.message.includes("ECONNREFUSED")) {
      return NextResponse.json(
        {
          success: false,
          error: "Cannot connect to Python API server",
          details: "Connection refused. The Python server is not running on port 5000.",
          instructions: [
            "1. Install dependencies: pip install flask flask-cors",
            "2. Start the server: python scripts/start_server.py",
            "3. Verify it's running at http://localhost:5000",
          ],
        },
        { status: 503 },
      )
    }

    if (error.message.includes("fetch")) {
      return NextResponse.json(
        {
          success: false,
          error: "Network error connecting to Python API server",
          details: "Unable to establish connection. Please ensure the Python server is running.",
          instructions: [
            "1. Check if Python is installed",
            "2. Install dependencies: pip install flask flask-cors",
            "3. Start the server: python scripts/start_server.py",
            "4. Verify the server starts without errors",
          ],
        },
        { status: 503 },
      )
    }

    return NextResponse.json(
      {
        success: false,
        error: "Connection error",
        details: error.message,
        instructions: [
          "1. Ensure Python server is running: python scripts/start_server.py",
          "2. Check that port 5000 is not blocked",
          "3. Verify Flask dependencies are installed",
        ],
      },
      { status: 503 },
    )
  }
}

export async function GET(request: NextRequest, { params }: { params: { path: string[] } }) {
  const path = params.path.join("/")
  const searchParams = request.nextUrl.searchParams.toString()
  const url = `${PYTHON_API_BASE}/${path}${searchParams ? `?${searchParams}` : ""}`

  return makeRequest(url, { method: "GET" })
}

export async function POST(request: NextRequest, { params }: { params: { path: string[] } }) {
  const path = params.path.join("/")
  const url = `${PYTHON_API_BASE}/${path}`

  let body = {}
  try {
    body = await request.json()
  } catch (e) {
    console.log("[API Proxy] No JSON body or invalid JSON")
  }

  return makeRequest(url, {
    method: "POST",
    body: JSON.stringify(body),
  })
}

export async function DELETE(request: NextRequest, { params }: { params: { path: string[] } }) {
  const path = params.path.join("/")
  const url = `${PYTHON_API_BASE}/${path}`

  return makeRequest(url, { method: "DELETE" })
}
