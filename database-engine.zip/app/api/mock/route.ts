import { NextResponse } from "next/server"

// Mock data for when Python server is not available
const mockTables = ["users", "products", "orders"]

const mockUsers = [
  { id: 1, name: "John Doe", email: "john@example.com", age: 30 },
  { id: 2, name: "Jane Smith", email: "jane@example.com", age: 25 },
  { id: 3, name: "Bob Johnson", email: "bob@example.com", age: 35 },
]

const mockProducts = [
  { id: 1, name: "Laptop", price: 999.99, category: "Electronics" },
  { id: 2, name: "Book", price: 19.99, category: "Education" },
  { id: 3, name: "Coffee Mug", price: 12.5, category: "Kitchen" },
]

const mockTableInfo = {
  users: {
    name: "users",
    columns: [
      { name: "id", type: "INT", primary_key: true, nullable: false },
      { name: "name", type: "VARCHAR", size: 50, primary_key: false, nullable: false },
      { name: "email", type: "VARCHAR", size: 100, primary_key: false, nullable: true },
      { name: "age", type: "INT", primary_key: false, nullable: true },
    ],
    total_records: 3,
    total_pages: 1,
    indexes: ["idx_users_email"],
  },
  products: {
    name: "products",
    columns: [
      { name: "id", type: "INT", primary_key: true, nullable: false },
      { name: "name", type: "VARCHAR", size: 100, primary_key: false, nullable: false },
      { name: "price", type: "FLOAT", primary_key: false, nullable: true },
      { name: "category", type: "VARCHAR", size: 50, primary_key: false, nullable: true },
    ],
    total_records: 3,
    total_pages: 1,
    indexes: [],
  },
}

const mockStats = {
  total_tables: 2,
  total_records: 6,
  tables: {
    users: { records: 3, pages: 1, columns: 4, indexes: 1 },
    products: { records: 3, pages: 1, columns: 4, indexes: 0 },
  },
}

export async function GET() {
  return NextResponse.json({
    success: true,
    message: "Mock API is working",
    data: {
      tables: mockTables,
      users: mockUsers,
      products: mockProducts,
      tableInfo: mockTableInfo,
      stats: mockStats,
    },
  })
}
