import { type NextRequest, NextResponse } from "next/server"

// Mock data for demo mode
const mockTables = ["users", "products", "orders"]

const mockUsers = [
  { id: 1, name: "John Doe", email: "john@example.com", age: 30 },
  { id: 2, name: "Jane Smith", email: "jane@example.com", age: 25 },
  { id: 3, name: "Bob Johnson", email: "bob@example.com", age: 35 },
  { id: 4, name: "Alice Brown", email: "alice@example.com", age: 28 },
  { id: 5, name: "Charlie Wilson", email: "charlie@example.com", age: 42 },
]

const mockProducts = [
  { id: 1, name: "Laptop", price: 999.99, category: "Electronics", in_stock: true },
  { id: 2, name: "Book", price: 19.99, category: "Education", in_stock: true },
  { id: 3, name: "Coffee Mug", price: 12.5, category: "Kitchen", in_stock: false },
  { id: 4, name: "Smartphone", price: 699.99, category: "Electronics", in_stock: true },
  { id: 5, name: "Desk Chair", price: 149.99, category: "Furniture", in_stock: true },
]

const mockOrders = [
  { id: 1, user_id: 1, product_id: 1, quantity: 1, total: 999.99 },
  { id: 2, user_id: 2, product_id: 2, quantity: 2, total: 39.98 },
  { id: 3, user_id: 3, product_id: 4, quantity: 1, total: 699.99 },
]

const mockTableInfo = {
  users: {
    name: "users",
    columns: [
      { name: "id", type: "INT", primary_key: true, nullable: false },
      { name: "name", type: "VARCHAR", size: 50, primary_key: false, nullable: false },
      { name: "email", type: "VARCHAR", size: 100, primary_key: false, nullable: true },
      { name: "age", type: "INT", primary_key: false, nullable: true },
    ],
    total_records: 5,
    total_pages: 1,
    indexes: ["idx_users_email"],
  },
  products: {
    name: "products",
    columns: [
      { name: "id", type: "INT", primary_key: true, nullable: false },
      { name: "name", type: "VARCHAR", size: 100, primary_key: false, nullable: false },
      { name: "price", type: "FLOAT", primary_key: false, nullable: true },
      { name: "category", type: "VARCHAR", size: 50, primary_key: false, nullable: true },
      { name: "in_stock", type: "BOOLEAN", primary_key: false, nullable: true },
    ],
    total_records: 5,
    total_pages: 1,
    indexes: ["idx_products_category"],
  },
  orders: {
    name: "orders",
    columns: [
      { name: "id", type: "INT", primary_key: true, nullable: false },
      { name: "user_id", type: "INT", primary_key: false, nullable: false },
      { name: "product_id", type: "INT", primary_key: false, nullable: false },
      { name: "quantity", type: "INT", primary_key: false, nullable: true },
      { name: "total", type: "FLOAT", primary_key: false, nullable: true },
    ],
    total_records: 3,
    total_pages: 1,
    indexes: [],
  },
}

const mockStats = {
  total_tables: 3,
  total_records: 13,
  tables: {
    users: { records: 5, pages: 1, columns: 4, indexes: 1 },
    products: { records: 5, pages: 1, columns: 4, indexes: 1 },
    orders: { records: 3, pages: 1, columns: 5, indexes: 0 },
  },
}

function executeMockSQL(sql: string) {
  const sqlLower = sql.toLowerCase().trim()

  if (sqlLower.includes("select * from users")) {
    return { success: true, result: mockUsers }
  }

  if (sqlLower.includes("select * from products")) {
    return { success: true, result: mockProducts }
  }

  if (sqlLower.includes("select * from orders")) {
    return { success: true, result: mockOrders }
  }

  if (sqlLower.includes("select") && sqlLower.includes("where")) {
    return { success: true, result: [mockUsers[0]] }
  }

  if (sqlLower.includes("insert")) {
    return { success: true, result: "1 row inserted (demo mode)" }
  }

  if (sqlLower.includes("create table")) {
    return { success: true, result: "Table created successfully (demo mode)" }
  }

  if (sqlLower.includes("create index")) {
    return { success: true, result: "Index created successfully (demo mode)" }
  }

  return {
    success: false,
    error: "Query not supported in demo mode. Try: SELECT * FROM users;",
  }
}

export async function GET(request: NextRequest, { params }: { params: { path: string[] } }) {
  const path = params.path.join("/")

  // Simulate network delay
  await new Promise((resolve) => setTimeout(resolve, 100))

  switch (path) {
    case "health":
      return NextResponse.json({
        status: "healthy",
        message: "Demo mode - Database engine simulation",
        tables_count: 3,
      })

    case "tables":
      return NextResponse.json({
        success: true,
        tables: mockTables,
      })

    case "database/stats":
      return NextResponse.json({
        success: true,
        stats: mockStats,
      })

    default:
      // Handle table-specific requests
      if (path.startsWith("tables/")) {
        const parts = path.split("/")
        const tableName = parts[1]

        if (parts.length === 2) {
          // Get table info
          const tableInfo = mockTableInfo[tableName as keyof typeof mockTableInfo]
          if (tableInfo) {
            return NextResponse.json({
              success: true,
              table: tableInfo,
            })
          }
        }

        if (parts[2] === "data") {
          // Get table data
          const limit = Number.parseInt(request.nextUrl.searchParams.get("limit") || "10")
          const offset = Number.parseInt(request.nextUrl.searchParams.get("offset") || "0")

          let data: any[] = []
          if (tableName === "users") data = mockUsers
          else if (tableName === "products") data = mockProducts
          else if (tableName === "orders") data = mockOrders

          const paginatedData = data.slice(offset, offset + limit)

          return NextResponse.json({
            success: true,
            data: paginatedData,
            total: data.length,
            limit,
            offset,
          })
        }
      }

      return NextResponse.json(
        {
          success: false,
          error: "Endpoint not supported in demo mode",
        },
        { status: 404 },
      )
  }
}

export async function POST(request: NextRequest, { params }: { params: { path: string[] } }) {
  const path = params.path.join("/")

  // Simulate network delay
  await new Promise((resolve) => setTimeout(resolve, 200))

  if (path === "sql") {
    const body = await request.json()
    const sql = body.sql || ""
    return NextResponse.json(executeMockSQL(sql))
  }

  if (path === "tables") {
    return NextResponse.json({
      success: true,
      message: "Table created successfully (demo mode)",
    })
  }

  if (path.includes("/records")) {
    return NextResponse.json({
      success: true,
      message: "Record inserted successfully (demo mode)",
    })
  }

  if (path.includes("/indexes")) {
    return NextResponse.json({
      success: true,
      message: "Index created successfully (demo mode)",
    })
  }

  return NextResponse.json({
    success: true,
    message: "Operation completed (demo mode)",
  })
}

export async function DELETE(request: NextRequest, { params }: { params: { path: string[] } }) {
  // Simulate network delay
  await new Promise((resolve) => setTimeout(resolve, 150))

  return NextResponse.json({
    success: true,
    message: "Table deleted successfully (demo mode)",
  })
}
